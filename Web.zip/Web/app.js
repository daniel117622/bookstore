const express = require('express')
var pug = require('pug')
const bodyParser = require('body-parser')

const app = express()

app.use(express.static('public'))
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())

app.set('view engine','pug')

app.get('/empty',(req,res) => 
{
    res.render('layouts/main')
})
app.get('/ejemplo',(req,res) => 
{
    res.render('ejemplo')
})
app.post('/ejemplo', (req,res) => 
{
    console.log(req.body.email)
    res.render('layouts/main')
})

app.listen(3000)